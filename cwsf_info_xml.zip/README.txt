> CWSF
	> finalist
		@id = Project ID
		@name = Finalist name(s)
		@title = Project title
		@year = Project year (2005 - 2010)
		@category = Project category (this changes throughout the years)
		@division = Finalist division (Junior, Intermediate, Senior)
		@province = Finalist's province (two character code)
		@standing = Finalist's medal standing (bitmask: 1 - honorable mention; 2 - bronze medal; 4 - silver medal; 8 - gold medal; 16 - platinum award)
		@money = Total prize money and scholarships awarded to finalist
